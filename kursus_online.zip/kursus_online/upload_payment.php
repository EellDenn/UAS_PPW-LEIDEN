<?php
session_start();
require_once '../config/functions.php';
global $conn;

// Cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$course_id = $_POST['course_id'] ?? null;

// Pastikan folder upload ada
$uploadDir = '../uploads/payment_proof/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Proses upload
if ($course_id && isset($_FILES['proof_image'])) {
    $timestamp = time();
    $fileName = basename($_FILES['proof_image']['name']);
    $uniqueName = $timestamp . '_' . $fileName;

    $uploadFile = $uploadDir . $uniqueName;
    $relativePath = 'payment_proof/' . $uniqueName;

    // Validasi ekstensi file
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES['proof_image']['tmp_name'], $uploadFile)) {
            // Simpan ke database
            $stmt = $conn->prepare("INSERT INTO payments (user_id, course_id, proof_image, status) VALUES (:user_id, :course_id, :proof_image, 'pending')");
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':course_id', $course_id);
            $stmt->bindParam(':proof_image', $relativePath);

            if ($stmt->execute()) {
                $_SESSION['success_msg'] = "Bukti pembayaran berhasil diunggah.";
            } else {
                $_SESSION['error_msg'] = "Gagal menyimpan ke database: " . implode(" | ", $stmt->errorInfo());
            }
        } else {
            $_SESSION['error_msg'] = "Gagal mengunggah file: " . $_FILES['proof_image']['error'];
        }
    } else {
        $_SESSION['error_msg'] = "Format file tidak valid. Gunakan JPG, JPEG, PNG, atau GIF.";
    }
} else {
    $_SESSION['error_msg'] = "Data kursus atau file tidak lengkap.";
}

header("Location: ../profile.php");
exit;
