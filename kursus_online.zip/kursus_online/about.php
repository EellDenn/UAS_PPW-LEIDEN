<?php
require_once 'config/functions.php';
$pageTitle = "Tentang Kami";

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container my-5">
    <h2 class="text-center mb-5">Tentang Kami</h2>

    <div class="text-center mb-5">
        <img src="assets/images/courses/Leiden Course.png" class="img-fluid rounded" alt="Tentang Kami" style="max-height: 250px;">
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <h3>Visi Kami</h3>
            <p>Menjadi platform pembelajaran online terdepan yang memberikan akses pendidikan berkualitas bagi semua orang di Indonesia.</p>
            
            <h3 class="mt-4">Misi Kami</h3>
            <ul>
                <li>Menyediakan kursus online berkualitas dengan harga terjangkau</li>
                <li>Menghubungkan peserta dengan instruktur profesional</li>
                <li>Menciptakan pengalaman belajar yang interaktif dan menyenangkan</li>
            </ul>
        </div>
    </div>

   <!-- Bagian Pengembang -->
<div class="mt-5">
    <h3 class="text-center mb-4">Pengembang</h3>
    
    <div class="card p-3">
        <div class="row align-items-center">
            <div class="col-md-4 text-center">
                <img src="assets/images/courses/foto leiden putih.jpg" class="img-fluid rounded" alt="Pengembang" style="max-height: 300px;">
            </div>
            <div class="col-md-8">
                <h4>Leiden Fauzi Yoka Surya</h4>
                <p class="text-muted mb-1">Developer</p>
                <p>Mahasiswa aktif Semester 4 jurusan Sistem Informasi Universitas Sriwijaya yang bertanggung jawab atas seluruh pengembangan web.</p>
                <a href="https://www.instagram.com/lei.denn" target="_blank" class="text-primary">
                    <i class="fab fa-instagram fa-lg"></i>
                </a>
            </div>
        </div>
    </div>
</div>


<?php include 'includes/footer.php'; ?>
