<?php
require_once 'config/functions.php';
session_start();

if (!isset($_GET['id'])) {
    header("Location: courses.php");
    exit;
}

$courseId = $_GET['id'];
$course = getCourseById($courseId);

if (!$course) {
    header("Location: courses.php");
    exit;
}

$pageTitle = $course['title'];

// Cek apakah user sudah mendaftar kursus ini
$alreadyEnrolled = false;
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT * FROM enrollments WHERE user_id = :user_id AND course_id = :course_id");
    $stmt->bindParam(':user_id', $userId);
    $stmt->bindParam(':course_id', $courseId);
    $stmt->execute();
    $alreadyEnrolled = $stmt->rowCount() > 0;
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container my-5">
    <div class="row">
        <div class="col-md-8">
            <h1><?php echo $course['title']; ?></h1>
            <div class="mb-3">
                <span class="badge bg-primary me-2"><?php echo $course['duration']; ?> jam</span>
                <span class="text-muted">Oleh: <?php echo $course['instructor']; ?></span>
            </div>

            <div class="card mb-4">
                <img src="assets/images/courses/<?php echo $course['image']; ?>" class="card-img-top" alt="<?php echo $course['title']; ?>">
                <div class="card-body">
                    <h3 class="card-title">Deskripsi Kursus</h3>
                    <p class="card-text"><?php echo $course['description']; ?></p>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="mb-0">Materi Kursus</h3>
                </div>
                <div class="card-body">
                    <div class="accordion" id="courseAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                                    Modul 1: Pengenalan
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne">
                                <div class="accordion-body">
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-play-circle me-2"></i> Video 1: Pengenalan Materi</li>
                                        <li><i class="fas fa-play-circle me-2"></i> Video 2: Tools yang Dibutuhkan</li>
                                        <li><i class="fas fa-file-alt me-2"></i> Dokumen: Panduan Belajar</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                                    Modul 2: Dasar-dasar
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo">
                                <div class="accordion-body">
                                    <ul class="list-unstyled">
                                        <li><i class="fas fa-play-circle me-2"></i> Video 3: Konsep Dasar</li>
                                        <li><i class="fas fa-play-circle me-2"></i> Video 4: Praktek Sederhana</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card sticky-top" style="top: 20px;">
                <div class="card-body">
                    <h4 class="card-title">Rp <?php echo number_format($course['price'], 0, ',', '.'); ?></h4>

                    <?php if (isset($_SESSION['user_id'])): ?>
                        <?php if ($alreadyEnrolled): ?>
                            <button class="btn btn-secondary w-100 mb-3" disabled>Sudah Terdaftar</button>
                        <?php else: ?>
                            <form action="process/enroll_process.php" method="post" enctype="multipart/form-data">
                                <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">

                                <div class="mb-3">
                                    <label for="payment_method" class="form-label">Metode Pembayaran</label>
                                    <select name="payment_method" id="payment_method" class="form-select" required>
                                        <option value="">-- Pilih --</option>
                                        <option value="Transfer Bank">Transfer Bank</option>
                                        <option value="E-Wallet">E-Wallet</option>
                                        <option value="QRIS">QRIS</option>
                                    </select>
                                </div>

                                <div class="mb-3" id="payment_details"></div>

                                <div class="mb-3">
                                    <label for="payment_proof" class="form-label">Bukti Pembayaran</label>
                                    <input type="file" name="payment_proof" id="payment_proof" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required>
                                </div>

                                <button type="submit" class="btn btn-primary w-100 mb-3">Daftar Kursus</button>
                            </form>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary w-100 mb-3">Login untuk Mendaftar</a>
                    <?php endif; ?>

                    <ul class="list-group list-group-flush mb-3">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-clock me-2"></i>Durasi</span>
                            <span><?php echo $course['duration']; ?> jam</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-user-tie me-2"></i>Instruktur</span>
                            <span><?php echo $course['instructor']; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-certificate me-2"></i>Sertifikat</span>
                            <span>Ya</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript untuk tampilkan info pembayaran -->
<script>
document.getElementById('payment_method')?.addEventListener('change', function () {
    const paymentDetails = document.getElementById('payment_details');
    const method = this.value;

    let html = '';

    if (method === 'Transfer Bank') {
        html = `
            <label class="form-label">Rekening Tujuan</label>
            <div class="border p-2 rounded bg-light">
                BCA 1234567890 a.n. Leiden Course
            </div>
        `;
    } else if (method === 'E-Wallet') {
        html = `
            <label class="form-label">E-Wallet</label>
            <div class="border p-2 rounded bg-light mb-2">
                <strong>GoPay:</strong> 0812-3456-7890<br>
                <strong>OVO:</strong> 0812-3456-7891<br>
                <strong>ShopeePay:</strong> 0812-3456-7892
            </div>
        `;
    } else if (method === 'QRIS') {
        html = `
            <label class="form-label">Scan QRIS</label><br>
            <img src="assets/qris/qris_leiden.png" alt="QRIS" class="img-fluid rounded border" style="max-width: 200px;">
        `;
    }

    paymentDetails.innerHTML = html;
});
</script>

<?php include 'includes/footer.php'; ?>
