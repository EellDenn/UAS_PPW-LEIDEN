<?php
require_once 'config/functions.php';

if (isset($_SESSION['user_id'])) {
    header("Location: profile.php");
    exit;
}

$pageTitle = "Register";

include 'includes/header.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card shadow">
                <div class="card-body p-5">
                    <h2 class="card-title text-center mb-4">Daftar Akun Baru</h2>
                    
                    <form id="registerForm" action="process/register_process.php" method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                            <div id="emailFeedback" class="invalid-feedback"></div>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Daftar</button>
                    </form>
                    
                    <div class="text-center mt-3">
                        Sudah punya akun? <a href="login.php">Login disini</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
// Validasi email unik dengan AJAX
document.getElementById('email').addEventListener('blur', function() {
    const email = this.value;
    const emailField = this;
    const feedback = document.getElementById('emailFeedback');
    
    if (email) {
        fetch('process/check_email.php?email=' + email)
            .then(response => response.json())
            .then(data => {
                if (data.exists) {
                    emailField.classList.add('is-invalid');
                    feedback.textContent = 'Email sudah terdaftar!';
                } else {
                    emailField.classList.remove('is-invalid');
                }
            });
    }
});

// Validasi form
document.getElementById('registerForm').addEventListener('submit', function(e) {
    const password = document.getElementById('password');
    const confirm_password = document.getElementById('confirm_password');
    
    if (password.value !== confirm_password.value) {
        e.preventDefault();
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Password dan konfirmasi password tidak cocok!'
        });
    }
    
    // Cek jika email invalid
    if (document.getElementById('email').classList.contains('is-invalid')) {
        e.preventDefault();
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Email sudah terdaftar!'
        });
    }
});

// Tampilkan popup jika registrasi berhasil
<?php if (isset($_SESSION['register_success'])): ?>
    Swal.fire({
        icon: 'success',
        title: 'Sukses',
        text: '<?php echo $_SESSION['register_success']; unset($_SESSION['register_success']); ?>',
        confirmButtonText: 'OK'
    }).then(() => {
        window.location.href = 'login.php';
    });
<?php endif; ?>
</script>

<?php include 'includes/footer.php'; ?>