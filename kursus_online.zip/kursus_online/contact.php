<?php
session_start();
require_once 'config/functions.php';
$pageTitle = "Kontak";

// Proses kirim pesan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';

    // Simpan ke database
    $stmt = $conn->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $email, $subject, $message]);

    $_SESSION['success_message'] = "Pesan Anda berhasil dikirim!";
    header("Location: contact.php");
    exit;
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container my-5">
    <h2 class="text-center mb-5">Hubungi Kami</h2>

    <!-- Notifikasi berhasil -->
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $_SESSION['success_message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h3 class="card-title">Informasi Kontak</h3>
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <i class="fas fa-map-marker-alt me-2 text-primary"></i>
                            <strong>Alamat:</strong> Jl. Padat Karya Perumahan Griya Intikomp Palembang
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-phone me-2 text-primary"></i>
                            <strong>Telepon:</strong> +6285764377060
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-envelope me-2 text-primary"></i>
                            <strong>Email:</strong> leidencourse@gmail.com
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-clock me-2 text-primary"></i>
                            <strong>Jam Operasional:</strong> Senin - Jumat, 08:00 - 17:00 WIB
                        </li>
                    </ul>

                    <div class="mt-4">
                        <h4>Ikuti Kami</h4>
                        <div class="social-links">
                            <a href="https://www.instagram.com/lei.denn" target="_blank" class="text-primary">
                                <i class="fab fa-instagram fa-lg"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Kirim Pesan</h3>
                    <form method="post">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="subject" class="form-label">Subjek</label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Pesan</label>
                            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Kirim Pesan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-body">
            <h3 class="card-title">Lokasi Kami</h3>
            <div class="ratio ratio-16x9">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.5823444077732!2d104.80673309999999!3d-2.9356711!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e3b772242992c2d%3A0x401a4c4240165a99!2sGriya%20Intikomp!5e0!3m2!1sid!2sid!4v1746110062481!5m2!1sid!2sid" 
                    width="100%" 
                    height="450" 
                    style="border:0;" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
