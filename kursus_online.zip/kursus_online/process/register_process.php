<?php
session_start();
require_once '../config/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validasi
    $errors = [];
    
    // Cek email sudah terdaftar
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $_SESSION['error_msg'] = "Email sudah terdaftar!";
        header("Location: ../register.php");
        exit;
    }
    
    if ($password !== $confirm_password) {
        $_SESSION['error_msg'] = "Password dan konfirmasi password tidak cocok!";
        header("Location: ../register.php");
        exit;
    }
    
    // Register user
    if (registerUser($username, $email, $password)) {
        $_SESSION['register_success'] = "Registrasi berhasil! Silakan login.";
        header("Location: ../register.php");
        exit;
    } else {
        $_SESSION['error_msg'] = "Terjadi kesalahan saat registrasi!";
        header("Location: ../register.php");
        exit;
    }
} else {
    header("Location: ../register.php");
    exit;
}
?>