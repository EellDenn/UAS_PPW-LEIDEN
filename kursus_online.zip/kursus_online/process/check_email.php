<?php
require_once '../config/functions.php';

if (isset($_GET['email'])) {
    $email = $_GET['email'];
    
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    
    header('Content-Type: application/json');
    echo json_encode(['exists' => $stmt->rowCount() > 0]);
    exit;
}

header("HTTP/1.1 400 Bad Request");
exit;
?>