<?php
session_start();
require_once '../config/functions.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_msg'] = "Anda harus login terlebih dahulu!";
    header("Location: ../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['course_id'], $_POST['payment_method']) && isset($_FILES['payment_proof'])) {
    $user_id = $_SESSION['user_id'];
    $course_id = $_POST['course_id'];
    $payment_method = $_POST['payment_method'];

    // Upload file
    $targetDir = "../uploads/payment_proof/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $fileName = basename($_FILES["payment_proof"]["name"]);
    $targetFilePath = $targetDir . time() . "_" . $fileName;

    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
    $allowedTypes = array('jpg', 'jpeg', 'png', 'pdf');

    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES["payment_proof"]["tmp_name"], $targetFilePath)) {
            $fileNameForDB = basename($targetFilePath);

            // Simpan ke DB
            $stmt = $conn->prepare("INSERT INTO enrollments (user_id, course_id, payment_method, payment_proof) 
                                    VALUES (:user_id, :course_id, :payment_method, :payment_proof)");
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':course_id', $course_id);
            $stmt->bindParam(':payment_method', $payment_method);
            $stmt->bindParam(':payment_proof', $fileNameForDB);

            if ($stmt->execute()) {
                $_SESSION['success_msg'] = "Pendaftaran dan bukti pembayaran berhasil diunggah!";
                header("Location: ../profile.php");
                exit;
            } else {
                $_SESSION['error_msg'] = "Gagal menyimpan data!";
            }
        } else {
            $_SESSION['error_msg'] = "Gagal mengunggah file!";
        }
    } else {
        $_SESSION['error_msg'] = "Format file tidak diizinkan!";
    }

    header("Location: ../course_detail.php?id=$course_id");
    exit;
}

