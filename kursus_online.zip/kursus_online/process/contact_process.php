<?php
session_start();
require_once '../config/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    try {
        $stmt = $conn->prepare("INSERT INTO messages (name, email, subject, message) VALUES (:name, :email, :subject, :message)");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':subject', $subject);
        $stmt->bindParam(':message', $message);
        $stmt->execute();

        $_SESSION['success_msg'] = "Terima kasih, $name! Pesan Anda telah terkirim.";
    } catch (PDOException $e) {
        $_SESSION['error_msg'] = "Gagal mengirim pesan: " . $e->getMessage();
    }

    header("Location: ../contact.php");
    exit;
} else {
    header("Location: ../contact.php");
    exit;
}
