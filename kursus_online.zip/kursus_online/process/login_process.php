<?php
session_start();
require_once '../config/functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $user = loginUser($email, $password);
    
    if ($user) {
       // Di bagian setelah login sukses
$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['user_role'] = $user['role']; // Pastikan ini ada

// Redirect berdasarkan role
if ($user['role'] == 'admin') {
    header("Location: ../admin/dashboard.php");
} else {
    header("Location: ../index.php");
}
exit;
    } else {
        $_SESSION['error_msg'] = "Email atau password salah!";
        header("Location: ../login.php");
        exit;
    }
} else {
    header("Location: ../login.php");
    exit;
}
?>