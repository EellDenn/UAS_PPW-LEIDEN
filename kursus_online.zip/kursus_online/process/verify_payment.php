<?php
session_start();
require_once '../config/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payment_id'], $_POST['action'])) {
    $payment_id = (int)$_POST['payment_id'];
    $action = $_POST['action'];

    if (in_array($action, ['approve', 'reject'])) {
        $status = $action === 'approve' ? 'approved' : 'rejected';

        $stmt = $conn->prepare("UPDATE payments SET status = :status WHERE id = :id");
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $payment_id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $_SESSION['success_msg'] = "Status pembayaran berhasil diperbarui.";
        } else {
            $_SESSION['error_msg'] = "Gagal memperbarui status pembayaran.";
        }
    } else {
        $_SESSION['error_msg'] = "Aksi tidak valid.";
    }
}

header("Location: ../admin/admin_payment.php");
exit;
