<?php
session_start();
require_once '../config/functions.php';

// Cek login dan role
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Tambah atau Edit Kursus
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $instructor = $_POST['instructor'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];
    $image_name = null;

    // Handle upload gambar
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = '../assets/images/courses/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $tmp_name = $_FILES['image']['tmp_name'];
        $original_name = basename($_FILES['image']['name']);
        $image_name = time() . "_" . preg_replace('/[^a-zA-Z0-9\._-]/', '_', $original_name);
        move_uploaded_file($tmp_name, $upload_dir . $image_name);
    }

    if (isset($_POST['course_id'])) {
        // Edit kursus
        $course_id = $_POST['course_id'];
        $sql = "UPDATE courses SET title = :title, description = :description, instructor = :instructor,
                price = :price, duration = :duration";

        if ($image_name) {
            $sql .= ", image = :image";
        }
        $sql .= " WHERE id = :id";
    } else {
        // Tambah kursus baru
        $sql = "INSERT INTO courses (title, description, instructor, price, duration, image)
                VALUES (:title, :description, :instructor, :price, :duration, :image)";
    }

    $stmt = $conn->prepare($sql);
    if (isset($course_id)) {
        $stmt->bindParam(':id', $course_id);
    }
    $stmt->bindParam(':title', $title);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':instructor', $instructor);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':duration', $duration);
    $stmt->bindValue(':image', $image_name ?: (isset($edit_course['image']) ? $edit_course['image'] : null));

    if ($stmt->execute()) {
        $_SESSION['success_msg'] = isset($course_id) ? "Kursus berhasil diperbarui!" : "Kursus berhasil ditambahkan!";
        header("Location: manage_courses.php");
        exit;
    } else {
        $_SESSION['error_msg'] = "Terjadi kesalahan saat menyimpan data!";
    }
}

// Hapus kursus
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("SELECT image FROM courses WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $course = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($course && $course['image']) {
        @unlink('../assets/images/courses/' . $course['image']);
    }

    $stmt = $conn->prepare("DELETE FROM courses WHERE id = :id");
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        $_SESSION['success_msg'] = "Kursus berhasil dihapus!";
        header("Location: manage_courses.php");
        exit;
    } else {
        $_SESSION['error_msg'] = "Terjadi kesalahan saat menghapus data!";
    }
}

// Ambil data untuk edit
$edit_course = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM courses WHERE id = :id");
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $edit_course = $stmt->fetch(PDO::FETCH_ASSOC);
}

$pageTitle = "Kelola Kursus";
include '../includes/header.php';
include '../includes/navbar_admin.php';
?>

<div class="container-fluid">
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <h1 class="h2 mt-4">Kelola Kursus</h1>

        <?php if (isset($_SESSION['success_msg'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success_msg']; unset($_SESSION['success_msg']); ?></div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_msg'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error_msg']; unset($_SESSION['error_msg']); ?></div>
        <?php endif; ?>

        <!-- Form Tambah/Edit -->
        <div class="card mb-4">
            <div class="card-header">
                <h5><?php echo isset($edit_course) ? 'Edit Kursus' : 'Tambah Kursus Baru'; ?></h5>
            </div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data">
                    <?php if (isset($edit_course)): ?>
                        <input type="hidden" name="course_id" value="<?php echo $edit_course['id']; ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="title" class="form-label">Judul Kursus</label>
                        <input type="text" class="form-control" id="title" name="title"
                               value="<?php echo isset($edit_course) ? $edit_course['title'] : ''; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Deskripsi</label>
                        <textarea class="form-control" id="description" name="description" rows="3" required><?php
                            echo isset($edit_course) ? $edit_course['description'] : ''; ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="instructor" class="form-label">Instruktur</label>
                            <input type="text" class="form-control" id="instructor" name="instructor"
                                   value="<?php echo isset($edit_course) ? $edit_course['instructor'] : ''; ?>" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="price" class="form-label">Harga (Rp)</label>
                            <input type="number" class="form-control" id="price" name="price"
                                   value="<?php echo isset($edit_course) ? $edit_course['price'] : ''; ?>" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="duration" class="form-label">Durasi (jam)</label>
                            <input type="number" class="form-control" id="duration" name="duration"
                                   value="<?php echo isset($edit_course) ? $edit_course['duration'] : ''; ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="image" class="form-label">Gambar Kursus</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*">
                    </div>

                    <?php if (isset($edit_course) && !empty($edit_course['image'])): ?>
                        <div class="mb-3">
                            <img src="../assets/images/courses/<?php echo htmlspecialchars($edit_course['image']); ?>" alt="Gambar Kursus" style="max-height: 150px;">
                        </div>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary">
                        <?php echo isset($edit_course) ? 'Update Kursus' : 'Tambah Kursus'; ?>
                    </button>
                    <?php if (isset($edit_course)): ?>
                        <a href="manage_courses.php" class="btn btn-secondary">Batal</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <!-- Daftar Kursus -->
        <div class="card">
            <div class="card-header">
                <h5>Daftar Kursus</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Judul</th>
                                <th>Instruktur</th>
                                <th>Harga</th>
                                <th>Durasi</th>
                                <th>Gambar</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $courses = getCourses();
                            foreach ($courses as $index => $course): ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td><?php echo $course['title']; ?></td>
                                <td><?php echo $course['instructor']; ?></td>
                                <td>Rp <?php echo number_format($course['price'], 0, ',', '.'); ?></td>
                                <td><?php echo $course['duration']; ?> jam</td>
                                <td>
                                    <?php if (!empty($course['image'])): ?>
                                        <img src="../assets/images/courses/<?php echo $course['image']; ?>" style="height: 50px;">
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="manage_courses.php?edit=<?php echo $course['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <a href="manage_courses.php?delete=<?php echo $course['id']; ?>" class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Apakah Anda yakin ingin menghapus kursus ini?')">Hapus</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?>
