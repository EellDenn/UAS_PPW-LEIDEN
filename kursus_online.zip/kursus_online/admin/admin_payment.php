<?php
session_start();
require_once '../config/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$stmt = $conn->query("SELECT p.*, u.username, c.title FROM payments p 
                      JOIN users u ON p.user_id = u.id 
                      JOIN courses c ON p.course_id = c.id 
                      ORDER BY p.uploaded_at DESC");
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
include '../includes/navbar_admin.php';
?>

<div class="container my-5">
    <h3>Verifikasi Bukti Pembayaran</h3>

    <?php if (empty($payments)): ?>
        <div class="alert alert-warning">Belum ada bukti pembayaran.</div>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Pengguna</th>
                    <th>Kursus</th>
                    <th>Bukti</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($payments as $pay): ?>
                    <tr>
                        <td><?= htmlspecialchars($pay['username']); ?></td>
                        <td><?= htmlspecialchars($pay['title']); ?></td>
                        <td>
                            <img src="../<?= htmlspecialchars($pay['proof_image']); ?>" width="100">
                        </td>
                        <td>
                            <span class="badge bg-<?= $pay['status'] == 'approved' ? 'success' : ($pay['status'] == 'rejected' ? 'danger' : 'secondary'); ?>">
                                <?= ucfirst($pay['status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($pay['status'] == 'pending'): ?>
                                <form action="/kursus_online/process/verify_payment.php" method="POST">
                                    <input type="hidden" name="payment_id" value="<?= $pay['id']; ?>">
                                    <button name="action" value="approve" class="btn btn-sm btn-success">Setujui</button>
                                    <button name="action" value="reject" class="btn btn-sm btn-danger">Tolak</button>
                                </form>
                            <?php else: ?>
                                <em>Terverifikasi</em>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
