<?php
session_start();
require_once '../config/functions.php';

$pageTitle = "Pesan Masuk";
include '../includes/header.php';
include '../includes/navbar_admin.php';

// Ambil semua pesan
$stmt = $conn->query("SELECT * FROM messages ORDER BY created_at DESC");
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container my-5">
    <h2 class="mb-4">Daftar Pesan Masuk</h2>

    <?php if (count($messages) > 0): ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Subjek</th>
                        <th>Pesan</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messages as $index => $msg): ?>
                        <tr class="<?= $msg['is_read'] ? '' : 'table-warning' ?>">
                            <td><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($msg['name']) ?></td>
                            <td><?= htmlspecialchars($msg['email']) ?></td>
                            <td><?= htmlspecialchars($msg['subject']) ?></td>
                            <td><?= nl2br(htmlspecialchars($msg['message'])) ?></td>
                            <td><?= date('d-m-Y H:i', strtotime($msg['created_at'])) ?></td>
                            <td>
                                <?= $msg['is_read'] 
                                    ? '<span class="badge bg-success">Dibaca</span>' 
                                    : '<span class="badge bg-warning text-dark">Belum Dibaca</span>' ?>
                            </td>
                            <td>
                                <a href="mark_read.php?id=<?= $msg['id'] ?>" class="btn btn-sm btn-success mb-1">Tandai Dibaca</a><br>
                                <a href="delete_message.php?id=<?= $msg['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus pesan ini?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info">Belum ada pesan yang masuk.</div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
