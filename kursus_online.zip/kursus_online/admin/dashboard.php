<?php
session_start();
define('ADMIN_PATH', true); // Flag khusus halaman admin
require_once '../config/functions.php';

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$pageTitle = "Admin Dashboard";

include '../includes/header.php';
include '../includes/navbar_admin.php';
?>

<div class="container-fluid">
    <div class="row">
        <main class="col-12 px-4">

            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard Admin</h1>
            </div>

            <!-- Cards -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Total Kursus</h5>
                                    <h2 class="mb-0"><?php echo count(getCourses()); ?></h2>
                                </div>
                                <i class="fas fa-book fa-3x"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-success mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Total User</h5>
                                    <h2 class="mb-0"><?php 
                                        global $conn;
                                        $stmt = $conn->query("SELECT COUNT(*) FROM users");
                                        echo $stmt->fetchColumn();
                                    ?></h2>
                                </div>
                                <i class="fas fa-users fa-3x"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-info mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Pendaftaran</h5>
                                    <h2 class="mb-0"><?php 
                                        $stmt = $conn->query("SELECT COUNT(*) FROM enrollments");
                                        echo $stmt->fetchColumn();
                                    ?></h2>
                                </div>
                                <i class="fas fa-clipboard-list fa-3x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Courses -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Kursus Terbaru</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Judul</th>
                                    <th>Instruktur</th>
                                    <th>Harga</th>
                                    <th>Durasi</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $courses = getCourses(5);
                                foreach ($courses as $index => $course): ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo $course['title']; ?></td>
                                    <td><?php echo $course['instructor']; ?></td>
                                    <td>Rp <?php echo number_format($course['price'], 0, ',', '.'); ?></td>
                                    <td><?php echo $course['duration']; ?> jam</td>
                                    <td>
                                        <a href="../course_detail.php?id=<?php echo $course['id']; ?>" class="btn btn-sm btn-primary">Lihat</a>
                                        <a href="manage_courses.php?edit=<?php echo $course['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Recent Users -->
            <div class="card">
                <div class="card-header">
                    <h5>User Terbaru</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Tanggal Daftar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $stmt = $conn->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
                                $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($users as $index => $user): ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo $user['username']; ?></td>
                                    <td><?php echo $user['email']; ?></td>
                                    <td><span class="badge bg-<?php echo $user['role'] == 'admin' ? 'danger' : 'primary'; ?>"><?php echo ucfirst($user['role']); ?></span></td>
                                    <td><?php echo date('d M Y', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <a href="manage_users.php?edit=<?php echo $user['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>