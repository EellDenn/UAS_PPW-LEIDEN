<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="#">
      <img src="/kursus_online/assets/images/courses/logo.png" alt="Logo" width="30" height="30" class="d-inline-block align-text-top me-2">
      Leiden Course
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin" aria-controls="navbarAdmin" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="/kursus_online/admin/dashboard.php">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/kursus_online/admin/manage_courses.php">Kelola Kursus</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/kursus_online/admin/manage_users.php">Kelola User</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/kursus_online/admin/admin_payment.php">Verifikasi Pembayaran</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/kursus_online/admin/messages.php">Pesan</a>
        </li>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="/kursus_online/profile.php">Profil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/kursus_online/logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
