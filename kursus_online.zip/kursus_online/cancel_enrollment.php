<?php
require_once 'config/functions.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $course_id = $_POST['course_id'];

    $stmt = $conn->prepare("DELETE FROM enrollments WHERE user_id = :user_id AND course_id = :course_id");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':course_id', $course_id);

    if ($stmt->execute()) {
        header("Location: profile.php");
        exit;
    } else {
        echo "Gagal membatalkan kursus.";
    }
}
