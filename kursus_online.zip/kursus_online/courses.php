<?php
require_once 'config/functions.php';
$pageTitle = "Kursus";
$courses = getCourses();

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container my-5">
    <h2 class="text-center mb-4">Daftar Kursus</h2>
    
    <div class="row mb-4">
        <div class="col-md-6">
            <!-- Form pencarian -->
            <form class="d-flex" method="GET" action="courses.php">
                <input class="form-control me-2" type="search" name="search" placeholder="Cari kursus..." aria-label="Search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <button class="btn btn-outline-primary" type="submit">Cari</button>
            </form>
        </div>
        <div class="col-md-6 text-end">
            <!-- Dropdown filter -->
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown">
                    Filter
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'price_asc'])); ?>">Harga Terendah</a></li>
                    <li><a class="dropdown-item" href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'price_desc'])); ?>">Harga Tertinggi</a></li>
                    <li><a class="dropdown-item" href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'duration_asc'])); ?>">Durasi Terpendek</a></li>
                    <li><a class="dropdown-item" href="?<?php echo http_build_query(array_merge($_GET, ['sort' => 'duration_desc'])); ?>">Durasi Terpanjang</a></li>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="row">
        <?php foreach ($courses as $course): ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <img src="assets/images/courses/<?php echo $course['image']; ?>" class="card-img-top" alt="<?php echo $course['title']; ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $course['title']; ?></h5>
                    <p class="card-text"><?php echo substr($course['description'], 0, 100); ?>...</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="badge bg-primary"><?php echo $course['duration']; ?> jam</span>
                        <span class="fw-bold">Rp <?php echo number_format($course['price'], 0, ',', '.'); ?></span>
                    </div>
                </div>
                <div class="card-footer bg-white">
                    <a href="course_detail.php?id=<?php echo $course['id']; ?>" class="btn btn-primary w-100">Lihat Detail</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item disabled">
                <a class="page-link" href="#" tabindex="-1">Previous</a>
            </li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item">
                <a class="page-link" href="#">Next</a>
            </li>
        </ul>
    </nav>
</div>

<?php include 'includes/footer.php'; ?>
