<?php
require_once 'config/functions.php';
$pageTitle = "Home";
$courses = getCourses(3); // Ambil 3 kursus terbaru

include 'includes/header.php';
include 'includes/navbar.php';
include 'includes/carousel.php';
?>

<div class="container my-5">
    <h2 class="text-center mb-4">Kursus Populer</h2>
    <div class="row">
        <?php foreach ($courses as $course): ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <img src="assets/images/courses/<?php echo $course['image']; ?>" class="card-img-top" alt="<?php echo $course['title']; ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $course['title']; ?></h5>
                    <p class="card-text"><?php echo substr($course['description'], 0, 100); ?>...</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="badge bg-primary"><?php echo $course['duration']; ?> jam</span>
                        <span class="fw-bold">Rp <?php echo number_format($course['price'], 0, ',', '.'); ?></span>
                    </div>
                </div>
                <div class="card-footer bg-white">
                    <a href="course_detail.php?id=<?php echo $course['id']; ?>" class="btn btn-primary w-100">Lihat Detail</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="text-center mt-3">
        <a href="courses.php" class="btn btn-outline-primary">Lihat Semua Kursus</a>
    </div>
</div>

<?php include 'includes/footer.php'; ?>