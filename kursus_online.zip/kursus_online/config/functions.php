<?php
// config/functions.php

require_once 'database.php';

function getCourses($limit = null) {
    global $conn;

    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $sort = isset($_GET['sort']) ? $_GET['sort'] : '';

    $sql = "SELECT * FROM courses";
    $params = [];

    // Tambahkan filter pencarian
    if (!empty($search)) {
        $sql .= " WHERE title LIKE :search OR description LIKE :search";
        $params[':search'] = '%' . $search . '%';
    }

    // Tambahkan sorting
    switch ($sort) {
        case 'price_asc':
            $sql .= " ORDER BY price ASC";
            break;
        case 'price_desc':
            $sql .= " ORDER BY price DESC";
            break;
        case 'duration_asc':
            $sql .= " ORDER BY duration ASC";
            break;
        case 'duration_desc':
            $sql .= " ORDER BY duration DESC";
            break;
        default:
            $sql .= " ORDER BY id DESC";
            break;
    }

    // Tambahkan limit jika ada
    if ($limit) {
        $sql .= " LIMIT " . intval($limit);
    }

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getCourseById($id) {
    global $conn;

    $sql = "SELECT * FROM courses WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $id);
    $stmt->execute();

    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function registerUser($username, $email, $password) {
    global $conn;

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $hashed_password);

    return $stmt->execute();
}

// Di functions.php, perbaiki fungsi loginUser():
function loginUser($email, $password) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        return $user; // Pastikan termasuk kolom 'role'
    }
    return false;
}
?>
