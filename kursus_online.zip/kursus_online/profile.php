<?php
require_once 'config/functions.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Ambil data user
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$stmt->bindParam(':id', $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Ambil kursus yang diikuti + data pembayaran
$stmt = $conn->prepare("SELECT c.*, e.payment_method, e.payment_proof, e.payment_status 
                        FROM courses c 
                        JOIN enrollments e ON c.id = e.course_id 
                        WHERE e.user_id = :user_id");
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();
$enrolled_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Profil Pengguna";

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container my-5">
    <div class="row">
        <!-- Kolom kiri: Profil -->
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <h4><?php echo $user['username']; ?></h4>
                    <p class="text-muted mb-1"><?php echo $user['email']; ?></p>
                    <p class="mb-3">
                        <span class="badge bg-<?php echo $user['role'] == 'admin' ? 'danger' : 'primary'; ?>">
                            <?php echo ucfirst($user['role']); ?>
                        </span>
                    </p>
                </div>
            </div>
        </div>

        <!-- Kolom kanan: Kursus yang diikuti -->
        <div class="col-md-8">
            <h4>Kursus yang Diikuti</h4>
            <?php if (count($enrolled_courses) > 0): ?>
                <div class="row">
                    <?php foreach ($enrolled_courses as $course): ?>
                        <div class="col-md-12 mb-4">
                            <div class="card h-100">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="assets/images/courses/<?php echo $course['image']; ?>" class="img-fluid rounded-start" alt="<?php echo $course['title']; ?>">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo $course['title']; ?></h5>
                                            <p class="card-text"><?php echo substr($course['description'], 0, 100); ?>...</p>

                                            <ul class="list-unstyled mb-2">
                                                <li><strong>Metode Pembayaran:</strong> <?php echo $course['payment_method'] ?? '-'; ?></li>
                                                <li><strong>Bukti Pembayaran:</strong>
                                                    <?php if (!empty($course['payment_proof'])): ?>
                                                        <a href="uploads/payment_proof/<?php echo $course['payment_proof']; ?>" target="_blank">Lihat Bukti</a>
                                                    <?php else: ?>
                                                        Tidak ada
                                                    <?php endif; ?>
                                                </li>
                                                <li><strong>Status:</strong> 
                                                    <?php
                                                        $status = $course['payment_status'] ?? 'belum';
                                                        if ($status == 'pending') {
                                                            echo '<span class="badge bg-warning text-dark">Menunggu Verifikasi</span>';
                                                        } elseif ($status == 'approved') {
                                                            echo '<span class="badge bg-success">Diterima</span>';
                                                        } elseif ($status == 'rejected') {
                                                            echo '<span class="badge bg-danger">Ditolak</span>';
                                                        } else {
                                                            echo '<span class="badge bg-secondary">Belum Bayar</span>';
                                                        }
                                                    ?>
                                                </li>
                                            </ul>

                                            <div class="d-flex justify-content-between align-items-center mt-3">
                                                <a href="course_detail.php?id=<?php echo $course['id']; ?>" class="btn btn-sm btn-outline-primary me-2">
                                                    Lihat Kursus
                                                </a>
                                                <form action="cancel_enrollment.php" method="POST" onsubmit="return confirm('Yakin ingin membatalkan kursus ini?');" class="m-0">
                                                    <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">Batalkan Kursus</button>
                                                </form>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-info">Kamu belum mendaftar kursus apa pun.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
